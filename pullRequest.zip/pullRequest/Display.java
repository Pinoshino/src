package pullRequest;

import net.arnx.jsonic.JSON;

import java.io.*;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.net.URL;
import java.net.URLConnection;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;


public class Display {

   // 実際はGitHubReferrer2.javaのnormalPullを代入
   // String s = getSourceText( new URL(normalPull) );
   String contents = getSourceText( new URL("https://github.com/Pinoshino/src/pull/1/files") );


   System.out.println(contents);
 }

// webの文字情報をすべて取得する関数
public static String getSourceText(URL url) throws IOException {
InputStream in = url.openStream();
StringBuilder sb = new StringBuilder();
try {
BufferedReader bf = new BufferedReader(new InputStreamReader(in));
String s;
while ((s=bf.readLine())!=null) {
sb.append(s);
}
} finally {
in.close();
}
return sb.toString();
}
