package pullRequest;

import net.arnx.jsonic.JSON;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class Search_rename {

int i,j;
int del_flag=0, new_flag=0,rename_flag=0;

// Display.javaのcontents
// String str = contents;
String str = "中身となる文字列"; //個々に中身
String[] rows = str.split("\n", 0);

for (i=0; i<rows.length; i++) {
  // 矢印を含んでいてかつコメント行ではなかったら
  if (rows[i].contains(" → ") && !rows[i].contains("*")) {

      rename_flag = 1;
      // del_flag=1;  //削除された可能性
     /*
    ※ " → "を２つ使っている行があった場合は、１つ目の" → "の左の文字列を前のファイル名として取得、
       →の文字列を新しファイル名として取得する機能

       ここを期限までに実装できずにすみません。
    */

    else if (rows[i].contains("+")) {
      new_flag=1;   //新規ファイルの可能性
    }

  }
}

if(del_flag==1 && new_flag==1){
  rename_flag = 1;
}


}
