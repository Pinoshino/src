public static String getSourceText(URL url) throws IOException {
InputStream in = url.openStream();
StringBuilder sb = new StringBuilder();
try {
BufferedReader bf = new BufferedReader(new InputStreamReader(in));
String s;
while ((s=bf.readLine())!=null) {
sb.append(s);
}
} finally {
in.close();
}
return sb.toString();
}
